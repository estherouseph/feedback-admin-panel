import { Router } from 'express';
import mongoose from 'mongoose';
import Feedback from '../models/Feedback.js';

const router = Router();

function validatePayload(body) {
  const courseName = typeof body.courseName === 'string' ? body.courseName.trim() : '';
  const courseDuration = typeof body.courseDuration === 'string' ? body.courseDuration.trim() : '';
  const comments = typeof body.comments === 'string' ? body.comments.trim() : '';
  const rating = Number(body.rating);
  const errors = [];
  if (courseName.length < 2 || courseName.length > 100) errors.push('Course name must be 2–100 characters.');
  if (!courseDuration || courseDuration.length > 60) errors.push('Course duration is required (up to 60 characters).');
  if (comments.length < 5 || comments.length > 1000) errors.push('Comments must be 5–1000 characters.');
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) errors.push('Rating must be a whole number from 1 to 5.');
  return { errors, data: { courseName, courseDuration, comments, rating } };
}

router.get('/', async (_req, res, next) => {
  try {
    const feedback = await Feedback.find().sort({ createdAt: -1 }).lean();
    res.json(feedback.map(item => ({ ...item, courseId: `CRS-${String(item._id).slice(-6).toUpperCase()}` })));
  } catch (error) { next(error); }
});

router.get('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid feedback ID.' });
    const item = await Feedback.findById(req.params.id).lean();
    if (!item) return res.status(404).json({ message: 'Feedback not found.' });
    res.json({ ...item, courseId: `CRS-${String(item._id).slice(-6).toUpperCase()}` });
  } catch (error) { next(error); }
});

router.post('/', async (req, res, next) => {
  try {
    const { errors, data } = validatePayload(req.body);
    if (errors.length) return res.status(400).json({ message: errors.join(' ') });
    const created = await Feedback.create(data);
    res.status(201).json({ ...created.toObject(), courseId: `CRS-${String(created._id).slice(-6).toUpperCase()}` });
  } catch (error) { next(error); }
});

router.put('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid feedback ID.' });
    const { errors, data } = validatePayload(req.body);
    if (errors.length) return res.status(400).json({ message: errors.join(' ') });
    const updated = await Feedback.findByIdAndUpdate(req.params.id, data, { new: true, runValidators: true });
    if (!updated) return res.status(404).json({ message: 'Feedback not found.' });
    res.json({ ...updated.toObject(), courseId: `CRS-${String(updated._id).slice(-6).toUpperCase()}` });
  } catch (error) { next(error); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid feedback ID.' });
    const deleted = await Feedback.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Feedback not found.' });
    res.json({ message: 'Feedback deleted successfully.' });
  } catch (error) { next(error); }
});

export default router;
